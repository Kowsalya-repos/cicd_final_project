# CI/CD Pipeline Final Project

This project demonstrates a CI/CD pipeline using:
- GitHub Actions
- Tekton Pipelines
- OpenShift

Pipeline Steps:
1. Lint the code using flake8
2. Run unit tests using nose
3. Build the application
4. Deploy using OpenShift Pipelines

Repository Structure:
.github/workflows/workflow.yml
.tekton/tasks.yml

Author: Student Submission
